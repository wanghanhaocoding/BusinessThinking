package com.only4play.jpa.support;

/**
 * @author gim 2022/3/5 10:07 下午
 */
public interface EntityOperation {

}
