package com.only4play.security.base;


public abstract class BaseAuthenticationProvider {

}
