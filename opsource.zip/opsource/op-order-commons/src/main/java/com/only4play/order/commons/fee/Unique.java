package com.only4play.order.commons.fee;

/**
 * @author gim
 * 计算器唯一编码
 */
public interface Unique {

  /**
   * 获取唯一编码
   * @return
   */
  Integer getUniqueCode();
}