#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
@QueryEntities(value = {BaseJpaAggregate.class})
package ${package};

import com.only4play.jpa.support.BaseJpaAggregate;
import com.querydsl.core.annotations.QueryEntities;

