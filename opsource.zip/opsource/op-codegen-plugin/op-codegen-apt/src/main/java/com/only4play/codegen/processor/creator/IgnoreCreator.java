package com.only4play.codegen.processor.creator;

/**
 * @Author: Gim
 * @Description:
 */
public @interface IgnoreCreator {

}
