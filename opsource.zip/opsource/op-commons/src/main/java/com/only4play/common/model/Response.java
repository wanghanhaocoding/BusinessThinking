package com.only4play.common.model;

import java.io.Serializable;

public interface Response extends Serializable {
}