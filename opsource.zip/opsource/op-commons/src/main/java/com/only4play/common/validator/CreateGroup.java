package com.only4play.common.validator;

public interface CreateGroup extends ValidateGroup{

}
