package com.only4play.common.model;

import lombok.Data;

@Data
public class EnumVo {
  private String name;
  private Integer code;
  private String text;
}
